package securianFinancial.RetireCalc;


import org.testng.annotations.Test;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;


import pageObjects.DefaultCalcValues;
import pageObjects.PreRetirementCalc;
import pageObjects.ValidatingResults;
import resources.base;

public class HomePage extends base{
	public WebDriver driver;
	 PreRetirementCalc rc;
	 DefaultCalcValues dv;
	 ValidatingResults vr;
	 
	 public static Logger log =LogManager.getLogger(base.class.getName());
	 
	@BeforeTest
	public void initialize() throws IOException
	{
	
		 driver =initializeDriver();
		 log.info("driver is initiated");
		 rc=new PreRetirementCalc(driver);
		 dv=new DefaultCalcValues(driver);
		 vr=new ValidatingResults(driver);

	}
	
	@Test(dataProvider="getData")
	
	public void basePageNavigation(HashMap<String,String> retDetails) throws InterruptedException 
	{

		//one is inheritance

		// creating object to that class and invoke methods of it
		driver.get(prop.getProperty("url"));
		driver.manage().window().maximize();
		log.info("Calculator page is opened");
		//single responsibilty design pattern
		rc.getAge().ageIput(retDetails);
		log.info("age is given as input under age section");
		rc.getIncomeSavings().incomeInput(retDetails);
		log.info("income/savings is given as input under income/savings section");
		
		//setting strategy during runtime,(sending yes or no thorugh json file)
		rc.setSocialIncomeStrategy(retDetails.get("SocialSecurityIncome"));
		rc.selectYesNo(retDetails);
		
		dv.getdefaultValues().defaultValuesInput(retDetails);;
		dv.setPostretStrategy(retDetails.get("PostRetInflationInv"));
		dv.selectYesNo(retDetails);
		
		dv.getInvestmentexpectations().investmentExpectationsInput(retDetails);
		rc.clickCalculateButton().CalculateButton();
		log.info("Calculate button is clicked");
		
		//validating result page
		vr.getMessage().ResultTxt();
		log.info("Assertion is validated");
		
		
		
	}

	/*@AfterTest
	public void teardown()
	{
		
		driver.close();
		log.info("browser is closed"); 
	
		
	}

	*/
	  @DataProvider
	    //hashmaps,dataprovider, json, jackson,list
	    public Object[][] getData() throws IOException {
	        List<HashMap<String, String>> l=getJsonData(System.getProperty("user.dir")+"//src//test//java//DataLoads//retDetails.json");

	        return new Object[][]
	                {
	                        { l.get(0)} 
	                };
	    }

		
}

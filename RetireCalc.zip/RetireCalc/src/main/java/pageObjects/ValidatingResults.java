package pageObjects;


import org.openqa.selenium.WebDriver;



import pageComponents.ResultMessage;

public class ValidatingResults {
	
	WebDriver driver;

	
	
	public ValidatingResults(WebDriver driver)
	{
		this.driver = driver;
	}
	


public ResultMessage getMessage()
{
	return new ResultMessage(driver);
	
}

}
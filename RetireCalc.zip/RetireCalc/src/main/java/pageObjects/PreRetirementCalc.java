package pageObjects;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import abstractInterface.CheckSocialSecurityIncome;
import abstractInterface.StrategyFactor;
import pageComponents.Age;
import pageComponents.CalculateResults;
import pageComponents.IncomeSavings;

public class PreRetirementCalc{
	
	WebDriver driver;
	CheckSocialSecurityIncome selectRadioYN;
	private By calculate=By.cssSelector(".col-sm-4 button[data-tag-id=\"submit\"]");
	
	public PreRetirementCalc(WebDriver driver)
	{
		this.driver = driver;
	}
	


public Age getAge()
{
	return new Age(driver);
	
}
	

public IncomeSavings getIncomeSavings()

{
return new 	IncomeSavings(driver);
}


public void setSocialIncomeStrategy(String strategyType)

{
	StrategyFactor strategyFactor = new StrategyFactor(driver);
	selectRadioYN = strategyFactor.createStrategy(strategyType);

	this.selectRadioYN = selectRadioYN;
}


public CalculateResults clickCalculateButton() {
	
	return new CalculateResults(driver,calculate);
	
	
}
	



public void selectYesNo(HashMap<String, String> retDetails)

{
	selectRadioYN.selectYesNo(retDetails);
}


}

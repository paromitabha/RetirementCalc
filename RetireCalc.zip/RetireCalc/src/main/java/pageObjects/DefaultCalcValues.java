package pageObjects;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;

import abstractInterface.CheckSocialSecurityIncome;
import abstractInterface.StrategyFactor;
import abstractInterface.StrategyFactor2;
import pageComponents.defaultValues;
import pageComponents.investmentExpectations;

public class DefaultCalcValues {
	WebDriver driver;
	CheckSocialSecurityIncome selectRadioYN;
	public DefaultCalcValues(WebDriver driver)
	{
		this.driver = driver;
	}
	


public defaultValues getdefaultValues()
{
	return new defaultValues(driver);
	
}
	

public investmentExpectations getInvestmentexpectations()

{
return new investmentExpectations(driver);
}


public void setPostretStrategy(String strategyType)

{
	StrategyFactor2 strategyFactor = new StrategyFactor2(driver);
	selectRadioYN = strategyFactor.createStrategy(strategyType);
	
	//this.selectRadioYN = selectRadioYN;
}



public void selectYesNo(HashMap<String, String> retDetails)

{
	selectRadioYN.selectYesNo(retDetails);
}




}

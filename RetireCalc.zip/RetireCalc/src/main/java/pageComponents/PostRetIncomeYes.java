package pageComponents;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import abstractInterface.AbstractComponent;
import abstractInterface.CheckSocialSecurityIncome;

public class PostRetIncomeYes extends AbstractComponent implements CheckSocialSecurityIncome {

	private By radio=By.xpath("//fieldset[@id='include-inflation-container']//ul//label[contains(text(),'Yes')]");
	private By inflationrate=By.id("expected-inflation-rate");
	private By retAnnualincome=By.id("retirement-annual-income");
	
	
	
	public PostRetIncomeYes(WebDriver driver) {
		// TODO Auto-generated constructor stub
		super(driver);
	}

	@Override
	public void selectYesNo(HashMap<String, String> retDetails) {
		// TODO Auto-generated method stub
		
		findElement(radio).click();
		JavascriptExecutor(findElement(inflationrate),retDetails.get("InflationPer"));
		findElement(retAnnualincome).click();
		JavascriptExecutor(findElement(retAnnualincome),retDetails.get("PercentFinalAnnualIncome"));
		

	}

}


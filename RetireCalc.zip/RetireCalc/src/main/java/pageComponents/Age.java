package pageComponents;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import abstractInterface.AbstractComponent;

public class Age extends AbstractComponent{
	
	public WebDriver driver;
	
	public Age(WebDriver driver) {
		// TODO Auto-generated constructor stub
		super(driver);
	}

	
	
    private By currentAge=By.cssSelector("[id='current-age']");
	
	private By retirementAge=By.id("retirement-age");
	


public void ageIput(HashMap<String,String> retDetails)
{
	findElement(currentAge).sendKeys(retDetails.get("CurrentAge"));
	findElement(retirementAge).sendKeys(retDetails.get("RetirementAge"));
}
}
package pageComponents;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import abstractInterface.AbstractComponent;

public class defaultValues extends AbstractComponent{ 

	WebDriver driver;
	public defaultValues(WebDriver driver) {
		// TODO Auto-generated constructor stub
		super(driver);
	
	}


    private By additionalIncome=By.id("additional-income");
	
	private By retireDuration=By.id("retirement-duration");
	//private By retAnnualIncome=By.id("retirement-annual-income");


public void defaultValuesInput(HashMap<String,String> retDetails) 

{
	

	
	JavascriptExecutor(findElement(additionalIncome),retDetails.get("AdditionalIncome"));
	findElement(retireDuration).click();
	findElement(retireDuration).sendKeys(retDetails.get("NumYrsRetirementToLast"));
}


}




   
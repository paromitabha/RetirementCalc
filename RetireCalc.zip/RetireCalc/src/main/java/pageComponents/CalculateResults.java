package pageComponents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import abstractInterface.AbstractComponent;

public class CalculateResults extends AbstractComponent{ 

	WebDriver driver;
	By calculate;
	public CalculateResults(WebDriver driver, By calculate) {
		// TODO Auto-generated constructor stub
		super(driver,calculate);
		this.calculate=calculate;
	
	}


    //private By additionalIncome=By.id("additional-income");
    
    public void CalculateButton() {
	
    findElement(calculate).click();
    }

}

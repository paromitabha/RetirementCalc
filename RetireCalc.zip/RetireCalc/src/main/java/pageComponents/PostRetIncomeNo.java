package pageComponents;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import abstractInterface.AbstractComponent;
import abstractInterface.CheckSocialSecurityIncome;

public class PostRetIncomeNo extends AbstractComponent implements CheckSocialSecurityIncome {
	
	private By retAnnualincome=By.id("retirement-annual-income");
	

	public PostRetIncomeNo(WebDriver driver) {
		// TODO Auto-generated constructor stub
		super(driver);
	}

	@Override
	public void selectYesNo(HashMap<String, String> retDetails) {
		// TODO Auto-generated method stub
		 findElement(retAnnualincome).click();
		 JavascriptExecutor(findElement(retAnnualincome),retDetails.get("PercentFinalAnnualIncome"));
		
	}

}

package pageComponents;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import abstractInterface.AbstractComponent;
import abstractInterface.CheckSocialSecurityIncome;

public class SocialSecurityIncomeYes extends AbstractComponent implements CheckSocialSecurityIncome{
	WebDriver driver;
	private By radio=By.xpath("//fieldset[@id='include-social-container']//ul//label[contains(text(),'Yes')]");
	private By adjustButton=By.linkText("Adjust default values");
	private By ssOverrideAmount=By.id("social-security-override");
	
	public SocialSecurityIncomeYes(WebDriver driver)
	{
		super(driver);
	}

	@Override
	public void selectYesNo(HashMap<String,String> retDetails) {
		
		// TODO Auto-generated method stub
		
		
		findElement(radio).click();
		selectMaritalStatus(retDetails.get("RelationshipStatus"));
		findElement(ssOverrideAmount).click();
		findElement(ssOverrideAmount).sendKeys(retDetails.get("SocialSecurityOverride"));
		findElement(adjustButton).click();
		// findElement(calculate).click();
	}
	

	public void selectMaritalStatus(String Mstatus)

	{

		findElement(By.xpath("//fieldset[@id='marital-status-toggle-group']//ul//label[contains(text(),"+Mstatus+")]")).click();
		
		
	}

}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
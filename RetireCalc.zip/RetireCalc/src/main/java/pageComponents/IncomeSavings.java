package pageComponents;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import abstractInterface.AbstractComponent;


public class IncomeSavings extends AbstractComponent{
	
	WebDriver driver;

	public IncomeSavings(WebDriver driver) {
		// TODO Auto-generated constructor stub
		super(driver);
	}
	
	
	 
	private By currentIncome=By.cssSelector("input#current-income");
	private By spouseIncome=By.id("spouse-income");
	private By currentTotalSavings=By.id("current-total-savings");
	private By currentAnnualSavings=By.id("current-annual-savings");
	private By savingsIncreaseRate=By.id("savings-increase-rate");

		


	public void incomeInput(HashMap<String,String> retDetails) 
	
	
	{
		
		findElement(currentIncome).click();
		findElement(currentIncome).sendKeys(retDetails.get("CurrentAnnualIncome"));
		findElement(spouseIncome).click();
		findElement(spouseIncome).sendKeys(retDetails.get("SpouseAnnualIncome"));
		findElement(currentTotalSavings).click();
		findElement(currentTotalSavings).sendKeys(retDetails.get("CurrentRetirementSavings"));
		findElement(currentAnnualSavings).sendKeys(retDetails.get("CurrentRetirementContribution"));
		findElement(savingsIncreaseRate).sendKeys(retDetails.get("AnnualRetContriInc"));
		
	}
	
	
	
	
	

}

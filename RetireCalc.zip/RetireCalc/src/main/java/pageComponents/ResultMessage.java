package pageComponents;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


import abstractInterface.AbstractComponent;
import org.testng.asserts.SoftAssert;

public class ResultMessage extends AbstractComponent{

	WebDriver driver;
	
	
	public ResultMessage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		super(driver);
		
	}
	

	private By Results=By.xpath("//h3[contains(text(),'Results')]");


public void ResultTxt() throws InterruptedException

{
	Thread.sleep(5000);
		//Object of Class SoftAssert is created to use its methods
		SoftAssert softassert = new SoftAssert();
		System.out.println(findElement(Results).getText());

		softassert.assertTrue(findElement(Results).isDisplayed());
		
		
		softassert.assertAll();
	
}
}



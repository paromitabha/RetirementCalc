package pageComponents;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import abstractInterface.AbstractComponent;
import abstractInterface.CheckSocialSecurityIncome;

public class SocialSecurityIncomeNo extends AbstractComponent implements CheckSocialSecurityIncome{
	
	//private By radio=By.id("no-social-benefits");
	private By adjustButton=By.linkText("Adjust default values");
	
	
	public SocialSecurityIncomeNo(WebDriver driver)
	{
		super(driver);
	}

	@Override
	public void selectYesNo(HashMap<String,String> retDetails) {
		
		// TODO Auto-generated method stub
		// findElement(radio).click();
		 findElement(adjustButton).click();
		
		 //findElement(calculate).click();
	}
	

	}

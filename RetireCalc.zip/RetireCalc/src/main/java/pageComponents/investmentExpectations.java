package pageComponents;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import abstractInterface.AbstractComponent;

public class investmentExpectations extends AbstractComponent{ 
	public WebDriver driver;

	public investmentExpectations(WebDriver driver) {
		
		// TODO Auto-generated constructor stub
		super(driver);
	}
	
	private By preretirmentinc=By.id("retirement-annual-income");
	private By postRetiremntincome=By.id("post-retirement-roi");
	private By saveChangesButton=By.cssSelector(".col-sm-4 input[value=\"Save changes\"]");
	




public void investmentExpectationsInput(HashMap<String,String> retDetails)
{
	JavascriptExecutor(findElement(preretirmentinc),retDetails.get("PreRetInvestReturn"));
	JavascriptExecutor(findElement(postRetiremntincome),retDetails.get("PostRetInvestReturn"));
	findElement(saveChangesButton).click();
	
}
}


package abstractInterface;


import org.openqa.selenium.WebDriver;

import pageComponents.PostRetIncomeNo;
import pageComponents.PostRetIncomeYes;



public class StrategyFactor2 {
	 WebDriver driver;
	   
	    public StrategyFactor2(WebDriver driver) {
	        this.driver = driver;

	    }

	    public CheckSocialSecurityIncome createStrategy(String strategyType)
	    {
	        if(strategyType.equalsIgnoreCase("yes"))
	        {
	           return new PostRetIncomeYes(driver);
	        }
	        if(strategyType.equalsIgnoreCase("no"))
	        {
	            return new PostRetIncomeNo(driver);
	        }
	        return null;
	    }
	}


package abstractInterface;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;



public abstract class AbstractComponent {
	
	 WebDriver driver;
	 WebElement sectionElement;
	 
	 public AbstractComponent(WebDriver driver)
	 {
		 this.driver = driver;
	 }
	 
	 public AbstractComponent(WebDriver driver,By sectionElement)
	 {
		 this.driver = driver;
		 this.sectionElement= findElement(sectionElement);
	 }
	 
	 
	
	public WebElement findElement(By findElementsBy)
	
	{
		return driver.findElement(findElementsBy);
	}
	
	public void JavascriptExecutor(WebElement wb,String Value)
	{
		WebElement ed = wb;
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].value="+Value, ed);
	}

}

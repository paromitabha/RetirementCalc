package abstractInterface;


import org.openqa.selenium.WebDriver;

import pageComponents.SocialSecurityIncomeNo;
import pageComponents.SocialSecurityIncomeYes;


public class StrategyFactor {
	 WebDriver driver;
	   
	    public StrategyFactor(WebDriver driver) {
	        this.driver = driver;

	    }

	    public CheckSocialSecurityIncome createStrategy(String strategyType)
	    {
	        if(strategyType.equalsIgnoreCase("yes"))
	        {
	           return new SocialSecurityIncomeYes(driver);
	        }
	        if(strategyType.equalsIgnoreCase("no"))
	        {
	            return new SocialSecurityIncomeNo(driver);
	        }
	        return null;
	    }
	}


package abstractInterface;

import java.util.HashMap;

public interface CheckSocialSecurityIncome {
	
	void selectYesNo(HashMap<String,String> retDetails); 
	

}
